-- this setup file is run immediately after the regression database is (re)created
-- the file is optional but you likely want to create the extension
CREATE EXTENSION pg_resp;
